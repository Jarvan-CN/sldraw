#ifndef TEST_CONFIG_HPP
#define TEST_CONFIG_HPP

#include <string>

const std::string TEST_FILE_DIR = "/home/llk/project2/tests";

#endif


